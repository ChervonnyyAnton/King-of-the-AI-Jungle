# Agenda: King of the AI Jungle

| Zeit | Phase | Inhalt | Dauer |
|------|-------|--------|-------|
| **09:00** | **Start & Setup** | Troubleshooting & Environment Check (VS Code, Git, API-Keys) | 15 Min |
| **09:15** | **Einführung** | Agenda, Spielregeln, Lernziele | 2–3 Min |
| **09:18** | **Kontext** | Was ist "Agentic AI"? Aufbau des Setups (visual & simpel) | 3–5 Min |
| **09:23** | **Use Cases** | Praxisbeispiele aus echten Projekten | 5–7 Min |
| **09:28** | **Anatomie** | Begrifflichkeiten & Architektur im Detail | 5–7 Min |
| **09:35** | **Demo** | CLI-Befehl → Agentenerstellung in VS Code (Live) | 5–10 Min |
| **09:45** | **Guided Hands-On** | Teilnehmer erstellen eigenen Agenten nach Vorlage | 10–15 Min |
| **10:00** | **Q&A 1** | Offene Fragen, Common Pitfalls besprechen | 5–10 Min |
| ☕ | **Pause** | Coffee Break | 15 Min |
| **10:15** | **Repo-Setup** | GitHub auschecken (falls noch nicht geschehen), Struktur erklären | 2–3 Min |
| **10:18** | **Exploratives Testing** | Eigene/Repo-Agenten ausprobieren, Ergebnisse teilen | 5–10 Min |
| **10:28** | **Q&A 2** | Feedback, Anpassungen besprechen | 5–10 Min |
| **10:38** | **Open Lab** | **Freiraum: Eigene Agenten bauen & testen** (inkl. Instructor-Support) | 30 Min |
| ☕ | **Pause** | Coffee Break | 15 Min |
| **11:23** | **Vergleich & Outlook** | Claude Desktop (nur visuell/erzählerisch) | 5–7 Min |
| **11:30** | **Abschluss** | Takeaways, Resources, Feedback-Bogen, freier Ausklang | 5–10 Min |

### ⏱ Zeitmanagement
- **Aktive Zeit:** ~87–112 Minuten
- **Inkl. Pausen:** ~2 Std. 15 Min. – 2 Std. 40 Min.
- **Hard-Stop:** 11:40 Uhr (flexibler Puffer am Ende)

---
*Stand: Optimiert für maximale Praxisnähe und kognitive Entlastung.*
