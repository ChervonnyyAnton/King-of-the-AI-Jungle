# 🌴 King of the AI Jungle

> **Theme:** Agentic AI for QA. Local-First. No Cloud. 2-Axis Competence × AI Expertise Model.

## 📋 Project Dashboard
| Status | Progress | Budget |
|--------|----------|--------|
| 🟢 **Live** | 🟢 **Ready** | 💰 **$50.00** |

## 🚀 Quick Start
1. **Open** this folder in VS Code.
2. **Read** `WORKSHOP-CHALLENGE.md` to find your **Jungle Title** (Path Selector).
3. **Run** `npx serve mock/` in the terminal to start the app.
4. **Start** the "Jungle" by copying your path-specific prompt from `AGENTS.md`.

## 📂 Project Structure
*   **`mock/`**: The "Real App" (Single HTML file v2.0 with Debug Mode, Data Grid, Error Simulation).
*   **`docs/`**: Requirements, Tickets, Templates, and Instructor Guides.
*   **`tests/`**: SDET Automation Target.
*   **`AGENTS.md`**: Adaptive Prompts by Competence & AI Expertise.
*   **`SKILLS.md`**: AI Maturity Roadmap & Tool Proficiency.
*   **`WORKSHOP-CHALLENGE.md`**: Path Selector & Success Criteria.
*   **`docs/tools/INSTRUCTOR-QUICK-REF.md`**: **Primary instructor guide** — delivery checklist, troubleshooting, judging rubrics, pacing, and Day-0 mapping.

## 🆕 v2.0 New Features
- **Dynamic Data Grid:** Toggle-enabled table component with JSON data binding.
- **Error Simulation:** "Simulate Failure" button for testing error handling.
- **Enhanced Debug Mode:** Highlights dynamic elements and shows internal state.
- **Strict JSON Schema:** Validates grid data with detailed error messages.