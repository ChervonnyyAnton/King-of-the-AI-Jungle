# 🎫 JIRA-103: Print & PDF Optimization

**Status:** To Do  
**Priority:** High  

---

## 📝 Description
Ensure the "Preview" pane looks different from the "Print" pane. The Preview should look like a desktop app, while the Print view should be optimized for A4 paper.

## 🎯 Acceptance Criteria
1. **CSS Media Queries:** Use `@media print` to hide the sidebar.
2. **Formatting:** Ensure margins are correct for printing.
3. **Colors:** Ensure background colors are not printed (or explicitly forced).
