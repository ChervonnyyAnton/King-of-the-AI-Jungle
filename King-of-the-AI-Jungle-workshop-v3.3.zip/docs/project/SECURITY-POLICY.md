# 🛡️ Security Policy: Sandbox PDF Generator

## ⚠️ Data Handling & Privacy
*   **Client-Side Only:** All data processing happens locally. No data is sent to a server.
*   **Import:** Users can import JSON files. The app must handle malformed JSON gracefully without crashing.
*   **Print:** `window.print()` is used. No data is sent to the browser's print queue (except the visible content).

## 🔐 Security Testing Guidelines (For Risk Analysts)
When auditing `mock/index.html`, consider the following:

1.  **XSS (Cross-Site Scripting):**
    *   **Risk:** The "Import" feature parses user-uploaded JSON. If a user uploads a malicious script in the `body` field, it could execute.
    *   **Test:** Upload a JSON payload containing `<script>alert('XSS')</script>` and check if it executes.
2.  **Prototype Pollution:**
    *   **Risk:** If the JSON import logic uses a shallow merge, a user could pollute the `Object.prototype`.
    *   **Test:** Try importing a JSON object with `__proto__` keys.
3.  **File Size Limits:**
    *   **Risk:** Uploading a 500MB JSON file could freeze the browser tab (DoS).
    *   **Test:** Try importing a very large file (simulate or use a dummy large file).

## 📋 Compliance
*   **GDPR:** No PII (Personally Identifiable Information) is stored.
*   **Accessibility:** The app uses semantic HTML (`<header>`, `<footer>`) but lacks ARIA labels for the "Export" button.
