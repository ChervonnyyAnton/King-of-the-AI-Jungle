# 🌴 OpenCode Workshop Setup Guide

> **Welcome, Jungle Explorer.** This guide will walk you through setting up your **AI Pilot** (OpenCode) for the "King of the AI Jungle" workshop.

---

## 📦 Step 1: Install OpenCode

If you haven't already, install OpenCode globally:

```bash
npm install -g @anthropic/opencode
```

> 💡 **Verify installation:** Run `opencode --version`. You should see a version number (e.g., `v0.1.0`).

---

## 🔑 Step 2: Get Your AI Hub API Key

1. Contact your instructor or check the workshop Slack/Discord channel for your personal API key.
2. The key will be a long string starting with `sk-...` or `api-...`.
3. **Never share this key** with anyone else. It is tied to your workshop budget ($50).

---

## ⚙️ Step 3: Configure OpenCode

1. Copy the `opencode-workshop.json` file from the project root (`King-of-the-AI-Jungle/`).
2. Paste it into your OpenCode config directory:
   - **macOS/Linux:** `~/.config/opencode/opencode.json`
   - **Windows:** `%APPDATA%\opencode\opencode.json`
3. Replace the placeholders with your actual credentials:
   - `{YOUR_SOVEREIGN_KEY}` → Paste your API key here.
   - `{SOVEREIGN_URL}` → Use the URL provided by your instructor (usually `https://ai-hub.adesso-group.com/v1`).

> ⚠️ **If you don't have a key yet:** Skip this step. The instructor will provide a shared key or a pre-configured config file.

---

## 🚀 Step 4: Launch the Workshop

1. **Open the project folder** in VS Code:
   ```bash
   code ~/Projects/Mine/King-of-the-AI-Jungle
   ```
2. **Start the sandbox app** in a new terminal:
   ```bash
   npx serve mock/
   ```
   > The app will be available at `http://localhost:3000`.
3. **Launch OpenCode** in a third terminal:
   ```bash
   opencode
   ```
   > You should see the OpenCode TUI (Text User Interface) open.

---

## 🧠 Step 5: Pick Your Path

1. Open `WORKSHOP-CHALLENGE.md` in VS Code.
2. Use the **2-Axis Path Selector** to find your **Jungle Title** (e.g., Trail Explorer, Mechanic, King of the Jungle).
3. Open the `jungle-prompter` skill in OpenCode (type `/skill jungle-prompter` or click the skill icon).
4. Tell the AI your Jungle Title, and it will generate a ready-to-copy prompt block for you.

---

## 🛠️ Step 6: Use Your Workshop Skills

| Skill | Purpose | How to Activate |
|-------|---------|-----------------|
| 🌴 **Jungle Prompter** | Generate role-specific AI prompts | Type `/skill jungle-prompter` |
| 🛡️ **Artifact Validator** | Check if your work meets standards | Type `/skill artifact-validator` |

---

## 🆘 Troubleshooting

| Issue | Solution |
|-------|----------|
| **OpenCode won't start** | Check that `opencode-workshop.json` has valid JSON syntax. Run `python -m json.tool opencode-workshop.json` to validate. |
| **API Key rejected** | Ensure there are no trailing spaces or newlines in your key. Regenerate the key from the AI Hub dashboard. |
| **Sandbox app won't load** | Make sure `node` and `npm` are installed. Run `npm install serve` and try `npx serve mock/` again. |
| **AI says "I don't have permission"** | OpenCode permissions are set to `deny: ["git", "curl", "ssh"]`. This is intentional to keep the workshop safe. |
| **Budget exceeded ($50)** | The AI will alert you. Switch to direct prompts (no CoT) and disable cloud model fallback. |

---

*Ready for the Jungle? Execute STLC. Win the Jungle.* 🐾
