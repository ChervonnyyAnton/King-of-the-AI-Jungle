# ⚠️ REDIRECT: Prompt Library

> **This file is deprecated.** All prompts, roles, and skills have been consolidated into **`AGENTS.md`** and **`SKILLS.md`**.

- **For Prompts:** Open `AGENTS.md` and find your **Jungle Title** (e.g., Trail Explorer, Automation Wizard).
- **For Tools:** Open `SKILLS.md` to learn the AI Maturity Roadmap.
- **For Paths:** Open `WORKSHOP-CHALLENGE.md` to select your Competence × AI Expertise path.

*This file will be removed in the next release.*
